import statistics
ages=[19,22,19,24,20,25,26,24,25,24] # creation of list
print(ages)
ages.sort()   # sorts the items of a list in ascending order
print(ages)
minimum= min(ages) #creation of variable named minimum to find out the min value in list using min()function
print ("min value element:", min(ages))
maximum= max(ages)#creation of variable named maximum to find out the max value in list using max()function
print("max value element:", max(ages))
add_min_val = 19
ages.append(add_min_val)#appends the object to the end of the list
print(ages)
add_max_val= 26
ages.append(add_max_val)
print(ages)
median_age= statistics.median(ages) #finds the median value from the list which is one middle item or two middle items divided by two
print("median of ages in list:", median_age)
mean_age= statistics.mean(ages)# finds the average by adding of all items divided by their numbers
print("mean of ages:", mean_age)
ages=[]
start, end =19,26
if start<end:
    ages.extend(range(start,end))
    ages.append(end)
print(ages)#starting from 0 by default and increments by 1 by default and ends at a specified number
range_of_the_given_ages= add_max_val - add_min_val
print("range of the ages:",range_of_the_given_ages)




dog={} # creation of empty dictionary
print(type(dog))  # Dictionaries are used to store data values in key:value pairs, ordered*, changeable and do not allow duplicates
dog={'name','color','breed','age','legs'}
print(dog)
dog={'name:snuby','color:golden','breed:retriever','age:2','legs:04'}
print(dog)
student_id={'first_name','last_name','gender','age','marital_status','skills','country','city','address'}
print(student_id)
print("student_id lenght:",len(student_id)) # calculates the length of a dictionary
student_id={'first_name':'ruchitha','last_name':'ES','gender':'female','age':'22','marital_status':'single','skills':'[{python,java ,C,HTML,DataBase,Machine Learning,Big DATA,Web apps, AI}]','country':'India', 'city':'hyderabad','address':'1234'}
res_list=student_id.values()
new_value=list(res_list)
print(type(new_value)) #prints the type of the variable
print(student_id)
print(type(student_id))
print(student_id.keys()) #An item has a key and a corresponding value that is expressed as a pair (key: value)
print(student_id.values())
print(list(student_id.keys())) # returns all the keys in lists
print(list(student_id.values())) # returns all the values in lists
student_id['skills']=list('c#,.net') #conversion of object from one data type to another data type
print(student_id)
print(type(student_id['skills'])) # returns the type of the given key("skills")




#creation of tuples and assigning values to it
sisters=('varsha' , 'dhrithi')  #tuples used to store multiple items in a single variable
brothers_2=('dhanishq','jathin')
siblings_3 =  sisters+brothers_2 # joining of tuples using + operator
print("siblings:", siblings_3)
siblings_3 = sisters + brothers_2
print("no_of_siblings:", len(siblings_3))# adding of new values to the tuple
my_family_members = ('Srinivas','Hima kiran,')+siblings_3
print('my_family:' , my_family_members)





it_companies = {'Facebook', 'Google', 'Microsoft', 'Apple', 'IBM', 'Oracle', 'Amazon'} # creates a set objects and it is unordered
print("the length of the set it_companies:",len(it_companies))  #  len() function returns the number of items in the set.
it_companies.update(['twitter'])
print(it_companies) # updates the current set, by adding items from another set (or any other iterable).
it_companies.discard("Microsoft")
print(it_companies) #discard:deosnt gives an error when data is not present
it_companies.remove("IBM")
print(it_companies)#remove:gives an error when data is not present
it_companies.update({'Cisco Systems', 'Samsung' ,'Blueberry'})
print(it_companies)
A = {19, 22, 24, 20, 25, 26}
B = {19, 22, 20, 25, 26, 24, 28, 27}
X=A.union(B) #returns a set that contains all items from the original set, and all items from the specified set(s)
print(X)
Y=A.intersection(B)  #returns a set that contains the similarity between two or more sets
print(Y)
print(A&B)
print(A.issubset(B))  #returns True if set A is the subset of B , i.e. if all the elements of set A are present in set B . Else, it returns False .
print(A.isdisjoint(B))  # checks whether the two sets are disjoint or not, if it is disjoint then it returns True otherwise it will return False.
print(A.symmetric_difference(B))   #returns a set that contains all items from both set, but not the items that are present in both sets
X.clear()  #removes all elements from the set
print(X)
age_in_list = [22, 19, 24, 25, 26, 24, 25, 24]
print("Age in list",len(age_in_list))
AGE_IN_SET= set(age_in_list)  #conversion of type from list to set
print("Age in set",AGE_IN_SET) #set() method is used to convert an iterable element such as a list, dictionary, or tuple into the set.
print("Age in set",len(AGE_IN_SET))







given_radius = 30
pi = 3.14
area_of_circle = pi*given_radius**2  #area of circle formulae
result = 'The area of circle with {} is {}'.format(str(given_radius), str(area_of_circle))
print(result)
circum_of_circle = 2*3.14*given_radius #area of circumference of circle formuale
print("the circumference of a circle:",circum_of_circle)
user_input=float(input()) #input from the user is read as a string and can be assigned to a variable
raaadius=20
area_of_circle=pi*raaadius**2
print(area_of_circle)





given_text ='I am a teacher and I love to inspire and teach people'
x=given_text.split() #splits a string into a list.
print(x)
ans=set(x) #converting the type into set to define the unique words
print(ans)
lennn=len(ans)
print("unique words used in the given text",lennn)






given_texT="Name\tAge\tCountry\tCity\tRuchitha\t22\tINDIA\tHyderabad" # escape sequences are indicated by a backslash ( \ )
print(given_texT)






radiUs = 10
radius_given_here=(input("enter radius:"))
areaofthecircle=int(3.14*radiUs**2)
print(f"the area of a circle with radius {radiUs} is {areaofthecircle} meters square ") # f is a way to format your string that is more readable and fast





conversionante=0.45
v=int(input("number of students")) #reading of the input from the user
l1=[]
l2=[]#empty list creation
for i in range(v):
    ele=input()
    l1.append(int(input("enter weight in lbs:"+str(i)+" "))) # use of mathematical operators
    l2.append(round(l1[i]*0.453,2))
print("given weights in lbs:",l1)
print("converted weights in kgs:",l2)






import pandas as pd
import numpy as np
data=pd.read _csv(r'F: \Campus X\Book1.csv')
data
X=data[' X']
Y=datal"Y']
X=X[:,np.newaxis]
from sklearn.model_selection import
train_test_split
X_train, X_test, Y_train, Y_test=train_test_sp
lit(X, Y, test_size=0.5)
X train

from sklearn.neighbors import
KNeighborsClassifier
knn=KNeighborsClassifier(n_neighbors=3).fit
(X_train,Y_train)
Y_pred=knn.predict(X_test)
from sklearn.metrics import
confusion_matrix, accuracy_score, recall_score
cm=confusion_matrix(Y_test, Y_pred)cm
acc=accuracy_score (Y_test, Y_pred)*100 acc
TN=cm[0, 0]
FN=cm[1,0]
FP=cm[0,1]
TP=cm[1,1]
sen= (TP / (TP+FN) )*100
sen

spec=(TN/(TN+FP))*100
spec
























